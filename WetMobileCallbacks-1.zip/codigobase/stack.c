
#include "stdlib.h"
#include "stack.h"
#include "stdio.h"


struct stack {
  int top;
  int *values;

};

Stack* new_stack(int size){
  Stack* s = calloc(1, sizeof(Stack));
  s->values= calloc(size, sizeof(int));
  s->top=0;
  return s;
}

void stack_push(Stack* s, int values){
    s->values[s->top++]=values;

}

int stack_pop(Stack* s){
    if(s->top == 0){
      printf ("stack empty\n");
      exit(1);
    }
    return s->values[--s->top];
}

void stack_print(Stack* s){
  printf("\n\n------stack----------\n\n");
  for(int i=0;i<s->top;i++){
      printf("\n%i\n", s->values[i]);
  
    }
  printf("\n\n------stack----------\n\n");
  
  
  
}